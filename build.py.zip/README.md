# Plainly - free tools website

A fast static website with 9 calculators/tools, built to earn from display ads.

## 1. Customise
Open `build.py` and edit the CONFIG block at the top:
- SITE_NAME / TAGLINE - your brand
- SITE_URL - your real domain (e.g. https://mytools.com)
- CONTACT_EMAIL - a real address you check (AdSense reviewers look for this)

## 2. Build
    python3 build.py
Everything you need is generated into the `dist/` folder.

## 3. Publish (free)
Upload `dist/` to Cloudflare Pages, Netlify or GitHub Pages, then attach your own domain
(about $10-15/year). AdSense requires your own domain, not a free subdomain.

## 4. Submit to Google
- Create a Google Search Console account, add your domain, submit `https://yourdomain.com/sitemap.xml`.

## 5. Apply for AdSense
- Apply once the site is live on your domain with the About, Privacy, Terms and Contact pages.
- Approval is not guaranteed and often needs some real traffic and original content first.
- After approval, put your IDs in CONFIG (ADSENSE_CLIENT and the three SLOTS), run `python3 build.py`, re-upload.
  The build also writes ads.txt automatically.
- Set PREVIEW_ADS = True to see where ad boxes will sit.

## 6. Grow traffic (this is the real work)
- Add 2-4 new tools per month. Copy an existing `tool(...)` block in build.py. Pick tools people search for;
  check each idea in Google Search results and Google Trends first.
- Target a specific audience/country for less competition (e.g. local-currency loan, tax, or unit tools).
- Write a unique title, description, intro and FAQ for each tool. Don't copy other sites.
- Share tools in relevant forums and communities, and earn links from blogs/directories.
- Be patient: new sites commonly take 3-6+ months to rank.

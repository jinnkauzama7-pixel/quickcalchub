#!/usr/bin/env python3
"""
Plainly - static site generator for a free-tools website.

1. Edit the CONFIG block below (name, domain, email, AdSense IDs).
2. Run:  python3 build.py
3. Upload the contents of the generated `dist/` folder to any static host.
"""
import html, json, os, shutil

# ----------------------------------------------------------------------------
# CONFIG - edit these
# ----------------------------------------------------------------------------
CFG = {
    "SITE_NAME": "Plainly",
    "TAGLINE": "Free online calculators and tools that just work",
    "SITE_URL": "https://example.com",       # your real domain, no trailing slash
    "CONTACT_EMAIL": "hello@example.com",
    "ADSENSE_CLIENT": "",                    # e.g. "ca-pub-1234567890123456" (leave empty until approved)
    "SLOTS": {"top": "", "mid": "", "side": ""},  # ad unit slot IDs from AdSense
    "PREVIEW_ADS": False,                    # True = show grey placeholder boxes so you can see layout
    "LASTMOD": "2026-09-28",
}

# ----------------------------------------------------------------------------
# TOOLS
# ----------------------------------------------------------------------------
TOOLS = []

def tool(**kw):
    TOOLS.append(kw)

tool(
    slug="percentage-calculator",
    name="Percentage Calculator",
    short="Find a percentage, a ratio, or a percent change.",
    title="Percentage Calculator - Free Online % Calculator",
    desc="Free percentage calculator. Work out X% of a number, what percent one number is of another, and percentage increase or decrease.",
    intro="Three common percentage problems in one place. Type your numbers and the answers update instantly.",
    ui="""
<h2>What is X% of Y?</h2>
<div class="row">
  <label>Percentage (%)<input id="a1" type="number" inputmode="decimal" value="15"></label>
  <label>Of this number<input id="b1" type="number" inputmode="decimal" value="200"></label>
</div>
<div class="result"><span class="big" id="r1"></span></div>

<h2>X is what percent of Y?</h2>
<div class="row">
  <label>Number<input id="a2" type="number" inputmode="decimal" value="30"></label>
  <label>Out of<input id="b2" type="number" inputmode="decimal" value="200"></label>
</div>
<div class="result"><span class="big" id="r2"></span></div>

<h2>Percentage change from X to Y</h2>
<div class="row">
  <label>Starting value<input id="a3" type="number" inputmode="decimal" value="80"></label>
  <label>Ending value<input id="b3" type="number" inputmode="decimal" value="100"></label>
</div>
<div class="result"><span class="big" id="r3"></span></div>
""",
    js="""
const pct=v=>Number.isFinite(v)?fmt(v,4)+'%':'-';
watch(['a1','b1','a2','b2','a3','b3'],()=>{
  $('r1').textContent=fmt(num('a1')/100*num('b1'),4);
  $('r2').textContent=pct(num('a2')/num('b2')*100);
  const c=(num('b3')-num('a3'))/Math.abs(num('a3'))*100;
  $('r3').textContent=Number.isFinite(c)?(c>0?'+':'')+fmt(c,4)+'%':'-';
});
""",
    howto=[
        "Pick the question that matches your problem: a percentage of a number, one number as a percent of another, or a change between two values.",
        "Enter your numbers in the two boxes. The result appears immediately below them.",
        "For percentage change, a positive result is an increase and a negative result is a decrease.",
    ],
    faqs=[
        ("How do I calculate a percentage of a number?", "Divide the percentage by 100 and multiply by the number. For example, 15% of 200 is 0.15 x 200 = 30."),
        ("How is percentage change calculated?", "Subtract the starting value from the ending value, divide by the starting value, then multiply by 100. Going from 80 to 100 is (100 - 80) / 80 x 100 = 25% increase."),
        ("Why does percent change show a dash?", "The starting value can't be zero, because you can't measure change relative to nothing."),
    ],
)

tool(
    slug="word-counter",
    name="Word Counter",
    short="Count words, characters, sentences and reading time.",
    title="Word Counter - Count Words, Characters & Reading Time",
    desc="Free word counter. Paste your text to count words, characters, sentences and paragraphs, and see estimated reading and speaking time.",
    intro="Paste or type your text below. Counts update as you write, and nothing leaves your browser.",
    ui="""
<label>Your text<textarea id="t" rows="10" placeholder="Start typing or paste your text here..."></textarea></label>
<div class="stats">
  <div><b id="w">0</b><span>Words</span></div>
  <div><b id="c">0</b><span>Characters</span></div>
  <div><b id="cn">0</b><span>Characters without spaces</span></div>
  <div><b id="s">0</b><span>Sentences</span></div>
  <div><b id="p">0</b><span>Paragraphs</span></div>
  <div><b id="rt">0</b><span>Reading time</span></div>
  <div><b id="st">0</b><span>Speaking time</span></div>
</div>
""",
    js="""
const mins=(w,wpm)=>w===0?'0 min':(w<wpm?'< 1 min':Math.ceil(w/wpm)+' min');
function up(){
  const t=$('t').value;
  const words=(t.trim().match(/\\S+/g)||[]).length;
  $('w').textContent=words.toLocaleString();
  $('c').textContent=t.length.toLocaleString();
  $('cn').textContent=t.replace(/\\s/g,'').length.toLocaleString();
  $('s').textContent=(t.match(/[^.!?]+[.!?]+|[^.!?]+$/g)||[]).filter(x=>x.trim()).length;
  $('p').textContent=t.split(/\\n\\s*\\n/).filter(x=>x.trim()).length;
  $('rt').textContent=mins(words,200);
  $('st').textContent=mins(words,130);
}
$('t').addEventListener('input',up);up();
""",
    howto=[
        "Type or paste your text into the box.",
        "Read the counts underneath. They update with every keystroke.",
        "Use the reading and speaking times to plan an essay, speech, post or video script.",
    ],
    faqs=[
        ("How are words counted?", "Any run of characters separated by spaces or line breaks counts as one word."),
        ("How is reading time estimated?", "We assume an average adult reads about 200 words per minute and speaks about 130 words per minute."),
        ("Is my text saved anywhere?", "No. Everything is calculated in your browser and your text is never uploaded."),
    ],
)

tool(
    slug="age-calculator",
    name="Age Calculator",
    short="Exact age in years, months and days.",
    title="Age Calculator - Calculate Exact Age in Years, Months & Days",
    desc="Free age calculator. Enter a date of birth to get exact age in years, months and days, total days lived, and days until the next birthday.",
    intro="Enter a date of birth to see an exact age. Change the second date to find someone's age on any day.",
    ui="""
<div class="row">
  <label>Date of birth<input id="dob" type="date"></label>
  <label>Age at date<input id="asof" type="date"></label>
</div>
<div class="result">
  <div class="big" id="ar">-</div>
  <div class="sub" id="ad"></div>
</div>
""",
    js="""
const t0=new Date();
$('asof').value=t0.getFullYear()+'-'+String(t0.getMonth()+1).padStart(2,'0')+'-'+String(t0.getDate()).padStart(2,'0');
const P=s=>{const a=s.split('-').map(Number);return new Date(a[0],a[1]-1,a[2]);};
watch(['dob','asof'],()=>{
  const a=$('dob').value,b=$('asof').value;
  if(!a||!b){$('ar').textContent='-';$('ad').textContent='Pick a date of birth.';return;}
  const d=P(a),n=P(b);
  if(d>n){$('ar').textContent='-';$('ad').textContent='Date of birth must be before the second date.';return;}
  let y=n.getFullYear()-d.getFullYear(),m=n.getMonth()-d.getMonth(),day=n.getDate()-d.getDate();
  if(day<0){m--;day+=new Date(n.getFullYear(),n.getMonth(),0).getDate();}
  if(m<0){y--;m+=12;}
  const total=Math.round((n-d)/86400000);
  let nb=new Date(n.getFullYear(),d.getMonth(),d.getDate());
  if(nb<n)nb=new Date(n.getFullYear()+1,d.getMonth(),d.getDate());
  const left=Math.round((nb-n)/86400000);
  $('ar').textContent=y+' years, '+m+' months, '+day+' days';
  $('ad').textContent=total.toLocaleString()+' days lived. '+(left===0?'Happy birthday!':left+' days until the next birthday.');
});
""",
    howto=[
        "Choose the date of birth.",
        "Leave the second date as today, or pick another date to find age on that day.",
        "Read the exact age, total days lived and the countdown to the next birthday.",
    ],
    faqs=[
        ("How is exact age calculated?", "We count full years from the birth date, then the remaining full months, then the remaining days."),
        ("Can I find someone's age on a past or future date?", "Yes. Change the 'Age at date' field to any date after the date of birth."),
        ("What about leap years?", "The calculation uses real calendar dates, so leap years are handled automatically."),
    ],
)

tool(
    slug="bmi-calculator",
    name="BMI Calculator",
    short="Body mass index in metric or imperial units.",
    title="BMI Calculator - Body Mass Index for Adults",
    desc="Free BMI calculator. Enter your height and weight in metric or imperial units to see your body mass index and healthy weight range.",
    intro="Enter your height and weight to see your body mass index. BMI is a screening measure, not a diagnosis.",
    ui="""
<label>Units
  <select id="u"><option value="met">Metric (cm, kg)</option><option value="imp">Imperial (ft, in, lb)</option></select>
</label>
<div class="row" id="m">
  <label>Height (cm)<input id="hcm" type="number" inputmode="decimal" value="170"></label>
  <label>Weight (kg)<input id="wkg" type="number" inputmode="decimal" value="70"></label>
</div>
<div class="row" id="i" hidden>
  <label>Height (ft)<input id="hft" type="number" inputmode="decimal" value="5"></label>
  <label>Height (in)<input id="hin" type="number" inputmode="decimal" value="7"></label>
  <label>Weight (lb)<input id="wlb" type="number" inputmode="decimal" value="154"></label>
</div>
<div class="result">
  <div class="big" id="bmi">-</div>
  <div class="sub" id="cat"></div>
  <div class="sub" id="rng"></div>
</div>
""",
    js="""
watch(['u','hcm','wkg','hft','hin','wlb'],()=>{
  const imp=$('u').value==='imp';
  $('m').hidden=imp;$('i').hidden=!imp;
  let h,w;
  if(imp){h=(num('hft')*12+(num('hin')||0))*0.0254;w=num('wlb')*0.45359237;}
  else{h=num('hcm')/100;w=num('wkg');}
  const b=w/(h*h);
  if(!Number.isFinite(b)||b<=0){$('bmi').textContent='-';$('cat').textContent='Enter your height and weight.';$('rng').textContent='';return;}
  $('bmi').textContent=b.toFixed(1);
  $('cat').textContent=b<18.5?'Underweight':b<25?'Healthy weight range':b<30?'Overweight range':'Obesity range';
  const lo=18.5*h*h,hi=24.9*h*h;
  $('rng').textContent='Healthy range for this height: '+(imp?fmt(lo/0.45359237,0)+' - '+fmt(hi/0.45359237,0)+' lb':fmt(lo,1)+' - '+fmt(hi,1)+' kg');
});
""",
    howto=[
        "Choose metric or imperial units.",
        "Enter your height and weight.",
        "Read your BMI and the weight range that falls in the 'healthy' BMI band for your height.",
    ],
    faqs=[
        ("What is a healthy BMI?", "For adults, the World Health Organization defines a BMI of 18.5 to 24.9 as the healthy weight range."),
        ("Is BMI accurate for everyone?", "No. BMI doesn't distinguish muscle from fat and isn't designed for children, pregnant women or some athletes. Talk to a health professional for personal advice."),
        ("How is BMI calculated?", "Weight in kilograms divided by height in metres squared."),
    ],
)

tool(
    slug="loan-emi-calculator",
    name="Loan EMI Calculator",
    short="Monthly payment, total interest and total cost of a loan.",
    title="Loan EMI Calculator - Monthly Payment & Total Interest",
    desc="Free loan EMI calculator. Enter loan amount, interest rate and term to see your monthly payment, total interest and total repayment.",
    intro="See what a loan really costs. Enter the amount, yearly interest rate and length to get the monthly instalment.",
    ui="""
<div class="row">
  <label>Loan amount<input id="amt" type="number" inputmode="decimal" value="500000"></label>
  <label>Interest rate (% per year)<input id="rate" type="number" inputmode="decimal" step="0.01" value="12"></label>
  <label>Term (years)<input id="yrs" type="number" inputmode="decimal" step="0.5" value="5"></label>
</div>
<div class="result">
  <div class="sub">Monthly payment (EMI)</div>
  <div class="big" id="emi">-</div>
  <div class="sub" id="ti"></div>
  <div class="sub" id="tp"></div>
</div>
""",
    js="""
watch(['amt','rate','yrs'],()=>{
  const P=num('amt'),r=num('rate')/1200,n=Math.round(num('yrs')*12);
  if(!(P>0)||!(n>0)||!(r>=0)){$('emi').textContent='-';$('ti').textContent='';$('tp').textContent='';return;}
  const emi=r===0?P/n:P*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1);
  $('emi').textContent=fmt(emi,2);
  $('ti').textContent='Total interest: '+fmt(emi*n-P,2);
  $('tp').textContent='Total repayment: '+fmt(emi*n,2)+' over '+n+' months';
});
""",
    howto=[
        "Enter the amount you plan to borrow, in any currency.",
        "Enter the yearly interest rate and the loan length in years.",
        "Read the monthly payment, total interest and total repayment. Try a shorter term to see how much interest you save.",
    ],
    faqs=[
        ("What does EMI mean?", "EMI stands for equated monthly instalment: the fixed amount you pay each month until the loan is cleared."),
        ("Which formula is used?", "EMI = P x r x (1+r)^n / ((1+r)^n - 1), where P is the loan amount, r the monthly rate and n the number of months."),
        ("Does this include fees?", "No. Processing fees, insurance and other charges aren't included, so your lender's figure may differ slightly."),
    ],
)

tool(
    slug="unit-converter",
    name="Unit Converter",
    short="Length, weight, volume, area, speed and temperature.",
    title="Unit Converter - Length, Weight, Volume, Temperature & More",
    desc="Free unit converter for length, weight, volume, area, speed and temperature. Convert between metric and imperial units instantly.",
    intro="Pick a category, choose two units and type a value. The conversion updates as you type.",
    ui="""
<div class="row">
  <label>Category<select id="cat"></select></label>
</div>
<div class="row">
  <label>Value<input id="val" type="number" inputmode="decimal" value="1"></label>
  <label>From<select id="from"></select></label>
  <label>To<select id="to"></select></label>
</div>
<div class="result"><div class="big" id="res">-</div><div class="sub" id="eq"></div></div>
""",
    js="""
const U={
 Length:{'metre (m)':1,'kilometre (km)':1000,'centimetre (cm)':0.01,'millimetre (mm)':0.001,'mile (mi)':1609.344,'yard (yd)':0.9144,'foot (ft)':0.3048,'inch (in)':0.0254},
 Weight:{'kilogram (kg)':1,'gram (g)':0.001,'milligram (mg)':0.000001,'pound (lb)':0.45359237,'ounce (oz)':0.028349523125,'tonne (t)':1000},
 Volume:{'litre (L)':1,'millilitre (mL)':0.001,'US gallon':3.785411784,'US cup':0.2365882365,'US fluid ounce':0.0295735295625,'cubic metre (m3)':1000},
 Area:{'square metre (m2)':1,'square kilometre (km2)':1000000,'hectare (ha)':10000,'acre':4046.8564224,'square foot (ft2)':0.09290304,'square mile (mi2)':2589988.110336},
 Speed:{'metre/second (m/s)':1,'kilometre/hour (km/h)':0.2777777778,'mile/hour (mph)':0.44704,'knot (kn)':0.5144444444},
 Temperature:{'Celsius (C)':0,'Fahrenheit (F)':0,'Kelvin (K)':0}
};
const toC=(v,u)=>u.startsWith('Fahr')?(v-32)*5/9:u.startsWith('Kelvin')?v-273.15:v;
const fromC=(v,u)=>u.startsWith('Fahr')?v*9/5+32:u.startsWith('Kelvin')?v+273.15:v;
function fill(sel,keys,pick){sel.innerHTML=keys.map((k,i)=>'<option'+(i===pick?' selected':'')+'>'+k+'</option>').join('');}
function loadCat(){
  const keys=Object.keys(U[$('cat').value]);
  fill($('from'),keys,0);fill($('to'),keys,Math.min(1,keys.length-1));
  calc();
}
function calc(){
  const c=$('cat').value,f=$('from').value,t=$('to').value,v=num('val');
  if(!Number.isFinite(v)){$('res').textContent='-';$('eq').textContent='';return;}
  const r=c==='Temperature'?fromC(toC(v,f),t):v*U[c][f]/U[c][t];
  $('res').textContent=fmt(r,6)+' '+t.replace(/^.*\\(|\\)$/g,'');
  $('eq').textContent=fmt(v,6)+' '+f+' = '+fmt(r,6)+' '+t;
}
fill($('cat'),Object.keys(U),0);
$('cat').addEventListener('change',loadCat);
['val','from','to'].forEach(i=>$(i).addEventListener('input',calc));
loadCat();
""",
    howto=[
        "Choose a category such as length, weight or temperature.",
        "Select the unit you are converting from and the unit you want.",
        "Type your value. The result and the full equation appear below.",
    ],
    faqs=[
        ("How many kilometres are in a mile?", "One mile is 1.609344 kilometres."),
        ("How do I convert Fahrenheit to Celsius?", "Subtract 32, then multiply by 5/9. So 68 F is (68 - 32) x 5/9 = 20 C."),
        ("Are these conversions exact?", "Length, weight, area and volume factors use the internationally agreed definitions. Results are rounded to six decimals for display."),
    ],
)

tool(
    slug="password-generator",
    name="Password Generator",
    short="Create strong random passwords in your browser.",
    title="Password Generator - Strong Random Passwords",
    desc="Free secure password generator. Create strong random passwords with your choice of length and characters. Generated in your browser, never stored.",
    intro="Generate a strong random password. It is created in your browser using your device's secure random number generator and is never sent or stored.",
    ui="""
<div class="pwbox">
  <input id="out" type="text" readonly aria-label="Generated password">
  <button id="copy" type="button">Copy</button>
</div>
<div class="sub" id="bits"></div>
<label>Length: <b id="lenv">16</b><input id="len" type="range" min="8" max="64" value="16"></label>
<div class="checks">
  <label><input id="lo" type="checkbox" checked> Lowercase (a-z)</label>
  <label><input id="up" type="checkbox" checked> Uppercase (A-Z)</label>
  <label><input id="di" type="checkbox" checked> Numbers (0-9)</label>
  <label><input id="sy" type="checkbox" checked> Symbols (!@#$...)</label>
</div>
<button id="gen" type="button">Generate new password</button>
""",
    js="""
const SETS={lo:'abcdefghijklmnopqrstuvwxyz',up:'ABCDEFGHIJKLMNOPQRSTUVWXYZ',di:'0123456789',sy:'!@#$%^&*()-_=+[]{};:,.?'};
function rnd(n){const a=new Uint32Array(1),lim=Math.floor(4294967296/n)*n;do{crypto.getRandomValues(a);}while(a[0]>=lim);return a[0]%n;}
function gen(){
  const L=+$('len').value;$('lenv').textContent=L;
  const chosen=Object.keys(SETS).filter(k=>$(k).checked);
  if(!chosen.length){$('out').value='';$('bits').textContent='Select at least one character type.';return;}
  const pool=chosen.map(k=>SETS[k]).join('');
  const chars=chosen.map(k=>SETS[k][rnd(SETS[k].length)]);
  while(chars.length<L)chars.push(pool[rnd(pool.length)]);
  for(let i=chars.length-1;i>0;i--){const j=rnd(i+1);[chars[i],chars[j]]=[chars[j],chars[i]];}
  $('out').value=chars.join('');
  const bits=Math.round(L*Math.log2(pool.length));
  $('bits').textContent='About '+bits+' bits of entropy - '+(bits<60?'weak':bits<80?'fair':bits<100?'strong':'very strong');
}
$('gen').addEventListener('click',gen);
['len','lo','up','di','sy'].forEach(i=>$(i).addEventListener('input',gen));
$('copy').addEventListener('click',async()=>{
  try{await navigator.clipboard.writeText($('out').value);$('copy').textContent='Copied';}
  catch(e){$('out').select();$('copy').textContent='Press Ctrl+C';}
  setTimeout(()=>$('copy').textContent='Copy',1500);
});
gen();
""",
    howto=[
        "Set the length. Longer is stronger; 16 characters or more is a good default.",
        "Choose which character types to include.",
        "Press Copy and paste the password into your password manager or sign-up form.",
    ],
    faqs=[
        ("Is this password generator safe?", "Yes. Passwords are made locally with the browser's cryptographically secure random generator. Nothing is sent to a server."),
        ("How long should a password be?", "At least 12 characters, and 16 or more for important accounts. Use a different password for every site and store them in a password manager."),
        ("What does entropy mean?", "Entropy in bits measures how many guesses an attacker would need. Every extra bit doubles the work."),
    ],
)

tool(
    slug="case-converter",
    name="Case Converter",
    short="UPPERCASE, lowercase, Title Case, camelCase and more.",
    title="Case Converter - Uppercase, Lowercase, Title Case & More",
    desc="Free online case converter. Change text to UPPERCASE, lowercase, Title Case, Sentence case, camelCase, snake_case or kebab-case in one click.",
    intro="Paste your text, then choose a format. The text is changed in place, and you can copy it with one click.",
    ui="""
<label>Your text<textarea id="t" rows="8" placeholder="Paste or type text here..."></textarea></label>
<div class="btns">
  <button type="button" data-m="upper">UPPERCASE</button>
  <button type="button" data-m="lower">lowercase</button>
  <button type="button" data-m="title">Title Case</button>
  <button type="button" data-m="sentence">Sentence case</button>
  <button type="button" data-m="camel">camelCase</button>
  <button type="button" data-m="snake">snake_case</button>
  <button type="button" data-m="kebab">kebab-case</button>
  <button type="button" id="copy" class="alt">Copy text</button>
</div>
""",
    js="""
const W=t=>t.replace(/([a-z0-9])([A-Z])/g,'$1 $2').split(/[^A-Za-z0-9]+/).filter(Boolean);
const M={
 upper:t=>t.toUpperCase(),
 lower:t=>t.toLowerCase(),
 title:t=>t.toLowerCase().replace(/(^|[\\s(\\-])([a-z])/g,(m,a,b)=>a+b.toUpperCase()),
 sentence:t=>t.toLowerCase().replace(/(^\\s*|[.!?]\\s+)([a-z])/g,(m,a,b)=>a+b.toUpperCase()),
 camel:t=>W(t).map((w,i)=>i?w[0].toUpperCase()+w.slice(1).toLowerCase():w.toLowerCase()).join(''),
 snake:t=>W(t).map(w=>w.toLowerCase()).join('_'),
 kebab:t=>W(t).map(w=>w.toLowerCase()).join('-')
};
document.querySelectorAll('[data-m]').forEach(b=>b.addEventListener('click',()=>{$('t').value=M[b.dataset.m]($('t').value);}));
$('copy').addEventListener('click',async()=>{
  try{await navigator.clipboard.writeText($('t').value);$('copy').textContent='Copied';}
  catch(e){$('t').select();$('copy').textContent='Press Ctrl+C';}
  setTimeout(()=>$('copy').textContent='Copy text',1500);
});
""",
    howto=[
        "Paste your text into the box.",
        "Click the format you want. The text is replaced straight away.",
        "Press Copy text, or click another format to keep converting.",
    ],
    faqs=[
        ("What is title case?", "Title case capitalises the first letter of each word, like 'The Quick Brown Fox'."),
        ("What are camelCase, snake_case and kebab-case for?", "They are naming styles used in programming for variables, files and URLs. camelCase joins words with capitals, snake_case with underscores and kebab-case with hyphens."),
        ("Can I undo a conversion?", "Use Ctrl+Z (Cmd+Z on Mac) inside the text box, or paste your original text again."),
    ],
)

tool(
    slug="discount-calculator",
    name="Discount Calculator",
    short="Sale price, amount saved and price after tax.",
    title="Discount Calculator - Sale Price & Savings",
    desc="Free discount calculator. Enter the original price and percent off to see the sale price, how much you save, and the final price with tax.",
    intro="Work out the real price of a sale. Add a tax rate if you want the final amount at the till.",
    ui="""
<div class="row">
  <label>Original price<input id="pr" type="number" inputmode="decimal" value="120"></label>
  <label>Discount (%)<input id="di" type="number" inputmode="decimal" value="25"></label>
  <label>Tax (%) - optional<input id="tx" type="number" inputmode="decimal" value="0"></label>
</div>
<div class="result">
  <div class="sub">You pay</div>
  <div class="big" id="fin">-</div>
  <div class="sub" id="sv"></div>
  <div class="sub" id="pt"></div>
</div>
""",
    js="""
watch(['pr','di','tx'],()=>{
  const p=num('pr'),d=num('di')||0,t=num('tx')||0;
  if(!(p>=0)||d<0||d>100){$('fin').textContent='-';$('sv').textContent='Enter a price and a discount between 0 and 100.';$('pt').textContent='';return;}
  const sale=p*(1-d/100);
  $('fin').textContent=fmt(sale*(1+t/100),2);
  $('sv').textContent='You save '+fmt(p*d/100,2)+' ('+fmt(d,2)+'% off)';
  $('pt').textContent='Sale price before tax: '+fmt(sale,2);
});
""",
    howto=[
        "Enter the original price and the percentage off.",
        "Add a tax rate if it is charged on top of the sale price.",
        "Read what you pay and how much you save.",
    ],
    faqs=[
        ("How do I calculate a discount?", "Multiply the price by the discount percentage divided by 100 to get the amount saved, then subtract it. 25% off 120 saves 30, so the price is 90."),
        ("Is tax applied before or after the discount?", "This calculator applies tax after the discount, which is how most shops do it."),
        ("What if there are two discounts?", "Apply them one after the other. 20% off then another 10% off is 28% off in total, not 30%."),
    ],
)

# ----------------------------------------------------------------------------
# STATIC PAGES
# ----------------------------------------------------------------------------
def pages():
    n, e, u = CFG["SITE_NAME"], CFG["CONTACT_EMAIL"], CFG["SITE_URL"]
    return {
        "about": ("About", f"About {n}", f"""
<p>{n} is a collection of free online calculators and everyday tools. Each one does a single job, loads quickly and works without an account.</p>
<h2>How we build our tools</h2>
<p>Every tool runs in your browser. The numbers and text you enter stay on your device. We check formulas against published references and test each tool with known examples before it goes live.</p>
<h2>How the site is funded</h2>
<p>{n} is free to use and supported by advertising. Ads are kept clear of the tools so they don't get in your way.</p>
<h2>Feedback</h2>
<p>Found a mistake or want a tool added? Email <a href="mailto:{e}">{e}</a>.</p>
"""),
        "privacy-policy": ("Privacy Policy", "Privacy Policy", f"""
<p>Last updated: {CFG['LASTMOD']}</p>
<p>This policy explains what information {n} ({u}) collects and how it is used.</p>
<h2>Information you enter into tools</h2>
<p>Text, numbers and dates you enter into our tools are processed in your browser. We do not upload, store or read them.</p>
<h2>Cookies and advertising</h2>
<p>We use Google AdSense to show ads. Google and its partners may use cookies to serve ads based on your visits to this and other websites. You can opt out of personalised advertising at <a href="https://adssettings.google.com">Google Ads Settings</a> or learn more at <a href="https://policies.google.com/technologies/ads">how Google uses information from sites that use its services</a>.</p>
<p>Where required by law, visitors are shown a consent choice before non-essential cookies are set.</p>
<h2>Log data</h2>
<p>Our hosting provider may record standard server logs such as IP address, browser type and pages requested, for security and reliability.</p>
<h2>Third-party links</h2>
<p>We are not responsible for the privacy practices of other websites we link to.</p>
<h2>Contact</h2>
<p>Questions about this policy: <a href="mailto:{e}">{e}</a>.</p>
"""),
        "terms": ("Terms of Use", "Terms of Use", f"""
<p>Last updated: {CFG['LASTMOD']}</p>
<p>By using {n} you agree to these terms.</p>
<h2>Information only</h2>
<p>Our calculators give estimates for general information. They are not financial, medical or legal advice. Check important results independently and consult a qualified professional before making decisions.</p>
<h2>No warranty</h2>
<p>We work to keep the tools accurate, but they are provided as is, without warranties of any kind. We are not liable for losses arising from their use.</p>
<h2>Acceptable use</h2>
<p>Do not misuse the site, attempt to disrupt it, or copy it in bulk without permission.</p>
<h2>Changes</h2>
<p>We may update these terms and the tools at any time.</p>
"""),
        "contact": ("Contact", "Contact us", f"""
<p>We read every message. Email us at <a href="mailto:{e}">{e}</a> for bug reports, tool requests, corrections or business enquiries.</p>
<p>Please include the tool name and the numbers you entered if you are reporting a wrong result.</p>
"""),
    }

# ----------------------------------------------------------------------------
# TEMPLATES
# ----------------------------------------------------------------------------
HEAD = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{TITLE}}</title>
<meta name="description" content="{{DESC}}">
<link rel="canonical" href="{{URL}}">
<meta property="og:type" content="website">
<meta property="og:title" content="{{TITLE}}">
<meta property="og:description" content="{{DESC}}">
<meta property="og:url" content="{{URL}}">
<meta name="twitter:card" content="summary">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='6' fill='%231F6F5C'/%3E%3Crect x='8' y='8' width='16' height='16' fill='%23F5C542'/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,800&family=Instrument+Sans:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/style.css">
{{ADSCRIPT}}
{{LD}}
</head>
<body>
<header class="site"><div class="wrap">
  <a class="brand" href="/"><i></i>{{SITE}}</a>
  <nav aria-label="Main"><a href="/#tools">All tools</a><a href="/about/">About</a></nav>
</div></header>
"""

FOOT = """
<footer class="site"><div class="wrap">
  <div>&copy; {{YEAR}} {{SITE}}. Results are estimates for information only.</div>
  <nav aria-label="Footer"><a href="/about/">About</a><a href="/privacy-policy/">Privacy</a><a href="/terms/">Terms</a><a href="/contact/">Contact</a></nav>
</div></footer>
{{SCRIPTS}}
</body>
</html>
"""

def fill(tpl, **kw):
    for k, v in kw.items():
        tpl = tpl.replace("{{" + k + "}}", v)
    return tpl

def ad(key):
    if CFG["ADSENSE_CLIENT"] and CFG["SLOTS"].get(key):
        return (f'<div class="ad" aria-label="Advertisement"><ins class="adsbygoogle" style="display:block" '
                f'data-ad-client="{CFG["ADSENSE_CLIENT"]}" data-ad-slot="{CFG["SLOTS"][key]}" '
                f'data-ad-format="auto" data-full-width-responsive="true"></ins>'
                f'<script>(adsbygoogle=window.adsbygoogle||[]).push({{}});</script></div>')
    if CFG["PREVIEW_ADS"]:
        return f'<div class="ad ad-preview">Ad space ({key})</div>'
    return ""

def head(title, desc, path, ld=""):
    adscript = ""
    if CFG["ADSENSE_CLIENT"]:
        adscript = (f'<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client='
                    f'{CFG["ADSENSE_CLIENT"]}" crossorigin="anonymous"></script>')
    return fill(HEAD, TITLE=html.escape(title), DESC=html.escape(desc, quote=True),
                URL=CFG["SITE_URL"] + path, ADSCRIPT=adscript, LD=ld, SITE=html.escape(CFG["SITE_NAME"]))

def foot(scripts=""):
    return fill(FOOT, YEAR="2026", SITE=html.escape(CFG["SITE_NAME"]), SCRIPTS=scripts)

def cards(items):
    return '<div class="cards">' + "".join(
        f'<a class="card" href="/{t["slug"]}/"><strong>{html.escape(t["name"])}</strong>'
        f'<span>{html.escape(t["short"])}</span></a>' for t in items) + "</div>"

def tool_page(t):
    path = f"/{t['slug']}/"
    others = [x for x in TOOLS if x["slug"] != t["slug"]]
    ld = '<script type="application/ld+json">' + json.dumps([
        {"@context": "https://schema.org", "@type": "WebApplication", "name": t["name"],
         "url": CFG["SITE_URL"] + path, "applicationCategory": "UtilitiesApplication",
         "operatingSystem": "Any", "description": t["desc"],
         "offers": {"@type": "Offer", "price": "0", "priceCurrency": "USD"}},
        {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
            {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}}
            for q, a in t["faqs"]]},
    ]) + "</script>"
    body = head(t["title"], t["desc"], path, ld)
    body += f"""
<div class="wrap">
<nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a> / {html.escape(t['name'])}</nav>
<div class="layout">
<main>
<h1>{html.escape(t['name'])}</h1>
<p class="lead">{html.escape(t['intro'])}</p>
{ad('top')}
<section class="tool" aria-label="{html.escape(t['name'])}">{t['ui']}</section>
{ad('mid')}
<section class="prose">
<h2>How to use the {html.escape(t['name'].lower())}</h2>
<ol>{"".join(f"<li>{html.escape(s)}</li>" for s in t['howto'])}</ol>
<h2>Frequently asked questions</h2>
<dl>{"".join(f"<dt>{html.escape(q)}</dt><dd>{html.escape(a)}</dd>" for q, a in t['faqs'])}</dl>
</section>
<section class="more"><h2>More free tools</h2>{cards(others[:6])}</section>
</main>
<aside><div class="aside-inner">
{ad('side')}
<div class="side-list"><h2>All tools</h2><ul>
{"".join(f'<li><a href="/{x["slug"]}/"' + (' aria-current="page"' if x["slug"] == t["slug"] else '') + f'>{html.escape(x["name"])}</a></li>' for x in TOOLS)}
</ul></div>
</div></aside>
</div></div>
"""
    body += foot('<script src="/common.js"></script>\n<script>\n' + t["js"] + "\n</script>")
    return body

def home_page():
    ld = '<script type="application/ld+json">' + json.dumps({
        "@context": "https://schema.org", "@type": "WebSite",
        "name": CFG["SITE_NAME"], "url": CFG["SITE_URL"] + "/"}) + "</script>"
    title = f'{CFG["SITE_NAME"]} - {CFG["TAGLINE"]}'
    desc = "Free online calculators and tools: percentage, word counter, age, BMI, loan EMI, unit converter, password generator and more. No sign-up."
    body = head(title, desc, "/", ld)
    body += f"""
<div class="wrap">
<section class="hero">
<h1>{html.escape(CFG['TAGLINE'])}</h1>
<p class="lead">Nine everyday tools. No sign-up, no downloads, and what you type never leaves your browser.</p>
</section>
{ad('top')}
<section id="tools"><h2 class="sr">All tools</h2>{cards(TOOLS)}</section>
{ad('mid')}
</div>
"""
    body += foot()
    return body

def static_page(slug, nav, h1, content):
    body = head(f"{h1} - {CFG['SITE_NAME']}", f"{h1} for {CFG['SITE_NAME']}.", f"/{slug}/")
    body += f'<div class="wrap narrow"><nav class="crumbs"><a href="/">Home</a> / {html.escape(nav)}</nav><main class="prose"><h1>{html.escape(h1)}</h1>{content}</main></div>'
    return body + foot()

# ----------------------------------------------------------------------------
# ASSETS
# ----------------------------------------------------------------------------
CSS = """
:root{--bg:#EDF1EE;--ink:#16202A;--muted:#55636E;--panel:#fff;--line:#CBD5CF;--accent:#1F6F5C;--hi:#F5C542;--well:#F4F7F5}
*{box-sizing:border-box}
[hidden]{display:none!important}
body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.6 "Instrument Sans",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
h1,h2,h3{font-family:"Bricolage Grotesque","Instrument Sans",system-ui,sans-serif;line-height:1.15;letter-spacing:-.01em;margin:0 0 .5em}
h1{font-size:clamp(1.9rem,4vw,2.7rem);font-weight:800}
h2{font-size:1.35rem;font-weight:600}
a{color:var(--accent)}
:focus-visible{outline:3px solid var(--hi);outline-offset:2px}
.wrap{max-width:1120px;margin:0 auto;padding:0 20px}
.narrow{max-width:760px}
.sr{position:absolute;left:-9999px}
header.site{background:var(--panel);border-bottom:1px solid var(--line)}
header.site .wrap{display:flex;align-items:center;justify-content:space-between;height:62px}
.brand{display:flex;align-items:center;gap:10px;font-family:"Bricolage Grotesque",system-ui,sans-serif;font-weight:800;font-size:1.4rem;color:var(--ink);text-decoration:none}
.brand i{width:22px;height:22px;border-radius:5px;background:var(--accent);position:relative}
.brand i::after{content:"";position:absolute;inset:5px;background:var(--hi)}
header.site nav a,footer.site nav a{margin-left:20px;color:var(--ink);text-decoration:none;font-weight:600}
header.site nav a:hover,footer.site nav a:hover{text-decoration:underline}
.crumbs{padding:16px 0 0;color:var(--muted);font-size:.9rem}
.crumbs a{color:var(--muted)}
.hero{padding:44px 0 20px;max-width:720px}
.lead{font-size:1.1rem;color:var(--muted);margin:0 0 1.2em;max-width:62ch}
.layout{display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:32px;padding:16px 0 48px}
.aside-inner{position:sticky;top:16px}
.tool{background:var(--panel);border:1px solid var(--line);border-top:4px solid var(--accent);border-radius:6px;padding:24px;margin:0 0 24px}
.tool h2{margin-top:1.2em;font-size:1.1rem}
.tool h2:first-child{margin-top:0}
label{display:block;font-weight:600;font-size:.92rem;margin:0 0 14px}
input,select,textarea,button{font:inherit}
input[type=number],input[type=date],input[type=text],select,textarea{display:block;width:100%;margin-top:6px;padding:.6rem .7rem;border:1px solid var(--line);border-radius:4px;background:#fff;color:var(--ink);font-weight:400}
textarea{resize:vertical;line-height:1.5}
input[type=range]{width:100%;margin-top:8px;accent-color:var(--accent)}
.row{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:0 16px}
.result{background:var(--well);border-left:4px solid var(--hi);border-radius:0 4px 4px 0;padding:12px 16px;margin-top:6px;font-variant-numeric:tabular-nums}
.big{font-family:"Bricolage Grotesque",system-ui,sans-serif;font-size:2rem;font-weight:800;line-height:1.2;overflow-wrap:anywhere}
.sub{color:var(--muted);font-size:.95rem}
button{cursor:pointer;background:var(--accent);color:#fff;border:0;border-radius:4px;padding:.65rem 1rem;font-weight:600}
button:hover{filter:brightness(1.1)}
button.alt{background:var(--ink)}
.btns{display:flex;flex-wrap:wrap;gap:8px}
.pwbox{display:flex;gap:8px;margin-bottom:8px}
.pwbox input{margin:0;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:1.1rem}
.checks{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:4px 16px;margin:14px 0}
.checks label{font-weight:400;margin:0}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px}
.stats div{background:var(--well);border-radius:4px;padding:10px 12px;border-left:4px solid var(--hi)}
.stats b{display:block;font-family:"Bricolage Grotesque",system-ui,sans-serif;font-size:1.6rem;line-height:1.2;font-variant-numeric:tabular-nums}
.stats span{font-size:.82rem;color:var(--muted)}
.prose{max-width:68ch}
.prose ol{padding-left:1.3em}
.prose li{margin-bottom:.4em}
.prose dt{font-weight:600;margin-top:1em}
.prose dd{margin:.2em 0 0;color:#2c3a45}
.more{margin-top:36px}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px}
.card{display:block;background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:16px;color:var(--ink);text-decoration:none}
.card:hover{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent)}
.card strong{display:block;font-family:"Bricolage Grotesque",system-ui,sans-serif;font-size:1.1rem;margin-bottom:4px}
.card span{color:var(--muted);font-size:.93rem;line-height:1.4;display:block}
.side-list{background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:16px;margin-top:16px}
.side-list h2{font-size:1rem}
.side-list ul{list-style:none;margin:0;padding:0}
.side-list li{padding:5px 0;border-top:1px solid var(--line)}
.side-list li:first-child{border-top:0}
.side-list a{text-decoration:none;color:var(--ink)}
.side-list a:hover,.side-list a[aria-current]{color:var(--accent);font-weight:600}
.ad{margin:0 0 24px;min-height:90px;text-align:center;overflow:hidden}
.ad-preview{display:flex;align-items:center;justify-content:center;border:2px dashed var(--line);color:var(--muted);font-size:.85rem}
footer.site{border-top:1px solid var(--line);background:var(--panel);padding:22px 0;color:var(--muted);font-size:.9rem}
footer.site .wrap{display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between}
@media(max-width:900px){.layout{grid-template-columns:1fr}.aside-inner{position:static}}
@media(max-width:520px){body{font-size:16px}.tool{padding:16px}header.site nav a{margin-left:12px}}
@media(prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
"""

COMMON_JS = """const $=id=>document.getElementById(id);
const num=id=>parseFloat($(id).value);
const fmt=(n,d=2)=>Number.isFinite(n)?n.toLocaleString(undefined,{maximumFractionDigits:d}):'-';
function watch(ids,fn){ids.forEach(i=>$(i).addEventListener('input',fn));fn();}
"""

README = """# Plainly - free tools website

A fast static website with 9 calculators/tools, built to earn from display ads.

## 1. Customise
Open `build.py` and edit the CONFIG block at the top:
- SITE_NAME / TAGLINE - your brand
- SITE_URL - your real domain (e.g. https://mytools.com)
- CONTACT_EMAIL - a real address you check (AdSense reviewers look for this)

## 2. Build
    python3 build.py
Everything you need is generated into the `dist/` folder.

## 3. Publish (free)
Upload `dist/` to Cloudflare Pages, Netlify or GitHub Pages, then attach your own domain
(about $10-15/year). AdSense requires your own domain, not a free subdomain.

## 4. Submit to Google
- Create a Google Search Console account, add your domain, submit `https://yourdomain.com/sitemap.xml`.

## 5. Apply for AdSense
- Apply once the site is live on your domain with the About, Privacy, Terms and Contact pages.
- Approval is not guaranteed and often needs some real traffic and original content first.
- After approval, put your IDs in CONFIG (ADSENSE_CLIENT and the three SLOTS), run `python3 build.py`, re-upload.
  The build also writes ads.txt automatically.
- Set PREVIEW_ADS = True to see where ad boxes will sit.

## 6. Grow traffic (this is the real work)
- Add 2-4 new tools per month. Copy an existing `tool(...)` block in build.py. Pick tools people search for;
  check each idea in Google Search results and Google Trends first.
- Target a specific audience/country for less competition (e.g. local-currency loan, tax, or unit tools).
- Write a unique title, description, intro and FAQ for each tool. Don't copy other sites.
- Share tools in relevant forums and communities, and earn links from blogs/directories.
- Be patient: new sites commonly take 3-6+ months to rank.
"""

# ----------------------------------------------------------------------------
# BUILD
# ----------------------------------------------------------------------------
def write(path, content):
    full = os.path.join("dist", path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)

def main():
    if os.path.isdir("dist"):
        shutil.rmtree("dist")
    write("index.html", home_page())
    for t in TOOLS:
        write(f"{t['slug']}/index.html", tool_page(t))
    for slug, (nav, h1, content) in pages().items():
        write(f"{slug}/index.html", static_page(slug, nav, h1, content))
    write("style.css", CSS.strip() + "\n")
    write("common.js", COMMON_JS)
    urls = ["/"] + [f"/{t['slug']}/" for t in TOOLS] + [f"/{s}/" for s in pages()]
    write("sitemap.xml", '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
          "".join(f"<url><loc>{CFG['SITE_URL']}{u}</loc><lastmod>{CFG['LASTMOD']}</lastmod></url>\n" for u in urls) + "</urlset>\n")
    write("robots.txt", f"User-agent: *\nAllow: /\n\nSitemap: {CFG['SITE_URL']}/sitemap.xml\n")
    if CFG["ADSENSE_CLIENT"]:
        pub = CFG["ADSENSE_CLIENT"].replace("ca-", "")
        write("ads.txt", f"google.com, {pub}, DIRECT, f08c47fec0942fa0\n")
    write("404.html", static_page("404", "Not found", "Page not found", '<p>That page does not exist. <a href="/">Browse all tools</a>.</p>'))
    print(f"Built {len(urls)} pages into dist/")

if __name__ == "__main__":
    main()
